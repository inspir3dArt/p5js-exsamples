class Ball {
  constructor(xPos, yPos) {
    this.position = new Vec2(xPos, yPos);
    this.velocity = new Vec2(
      map(mouseX, 0, width, -5, 5),
      map(mouseY, 0, height, -10, 0)
    );
    this.gravity = 0.15;
  }
  update() {
    this.position.add(this.velocity);
    this.velocity.y += this.gravity;
  }
  draw() {
    fill(128);
    noStroke();
    circle(this.position.x, this.position.y, 10);
  }
  getXpos() {
    return this.position.x;
  }
  getYpos() {
    return this.position.y;
  }
}