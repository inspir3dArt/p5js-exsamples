var gravity;
var balls;
var frame;

function setup() {
  createCanvas(windowWidth, displayHeight-5);
  balls = [];
  gravity = 0.15;
  frame = 0;
}
function draw() {
  background (0, 0, 0);
  ++frame;
  if (frame%5 == 0) {
    balls.push(new Ball(width/2, height));
  }
  for (var i = 0; i < balls.length; ++i) {
    if (balls[i].getYpos() > (height + 5)) {
      balls.splice(i, 1);
      --i;
    }
  }
  for(ball of balls) {
    ball.update();
    ball.draw();
  }
  noFill();
  stroke(255, 0, 0);
  circle(mouseX, mouseY, 10);
}
function doubleClicked() {
  fullscreen(true);
}